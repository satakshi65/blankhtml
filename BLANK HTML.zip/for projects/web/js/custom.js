//Loader

$(window).bind("load", function () {
    $(".loader-screen").hide();
});


//Sticky-Menu

$(window).scroll(function () {
    var scroll = $(window).scrollTop();

    if (scroll >= 10) {
        $(".main-header").addClass("sticky");
    } else {
        $(".main-header").removeClass("sticky");
    }
});


//Menu toggle responsive

$(".menu-toggle").click(function () {
    $(".menu").toggleClass("slide-right");
    $(this).find('i').toggleClass('fa-bars fa-times')
});





$(document).ready(function () {

    //Banner-slider

    $('.banner-slider').owlCarousel({
        loop: true,
        autoplay: true,
        margin: 0,
        nav: true,
        dots: false,
        animateIn: 'fadeIn',
        responsiveClass: true,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 1,

            },
            1000: {
                items: 1,
            }
        }
    })


    
    //map-container

    $('.map-container')
        .click(function () {
            $(this).find('iframe').addClass('clicked')
        })
        .mouseleave(function () {
            $(this).find('iframe').removeClass('clicked')
        });
});

